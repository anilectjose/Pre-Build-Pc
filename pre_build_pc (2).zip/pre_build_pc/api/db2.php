<?php
$con = new mysqli("localhost","root","","pre_build_pc_db");

if($con){

}
else{
	echo "Connection Failed";
	exit();
}
?>