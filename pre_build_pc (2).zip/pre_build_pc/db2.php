<?php
$con = mysqli_connect("localhost","root","","pre_build_pc_db");

?>